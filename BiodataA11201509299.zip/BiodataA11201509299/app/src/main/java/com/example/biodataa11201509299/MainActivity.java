package com.example.biodataa11201509299;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {
    Button buttonTlp; Button buttonMail; Button buttonAlamat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonTlp = (Button) findViewById(R.id.button3);
        buttonMail = (Button) findViewById(R.id.button4);
        buttonAlamat=(Button) findViewById(R.id.button);
        buttonAlamat.setOnClickListener(v -> openAlamat());
        buttonTlp.setOnClickListener(v -> openTelepon());
        buttonMail.setOnClickListener(v -> openMail());

    }

        public void openTelepon() {
        Intent intent=new Intent(this, telepon.class);
        startActivity(intent);

        }
        public void openMail() {
        Intent intent=new Intent(this, Mail.class);
        startActivity(intent);
        }
        public void openAlamat() {
        Intent intent = new Intent(this, alamat.class);
        startActivity(intent);
    }


}

